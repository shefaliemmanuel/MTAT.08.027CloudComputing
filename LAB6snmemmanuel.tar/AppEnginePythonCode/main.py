# Copyright 2016 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import webapp2
from google.appengine.api import users
import os
import urllib
from google.appengine.ext.webapp import blobstore_handlers
from google.appengine.ext import blobstore

class MainPage(webapp2.RequestHandler):
    def get(self):

        self.response.headers['Content-Type'] = 'text/html'

        self.response.write('<html><body>')

        self.response.write('This is Shefali Emmanuel Lab!'+'<br>')
        user = users.get_current_user()
        if user:
            self.response.write('Hello, ' + user.nickname() + '!'+'<br>'+'<br>')

        else:
            self.redirect(users.create_login_url(self.request.uri))

        upload_url = blobstore.create_upload_url('/upload')
        self.response.write('<form action="%s" method="POST" enctype="multipart/form-data">' % upload_url)
        self.response.write("""Upload File: <input type="file" name="myUploadedFile"><br />""")
        self.response.write("""<input type="submit" name="submit" value="Submit"> </form>""")
        for blob_info in blobstore.BlobInfo.all():
            self.response.write('<a href="/serve/' + str(blob_info.key()) + '">' + str(blob_info.filename) + "</a>" +'<br>')
        self.response.write('</body></html>')

class Upload(blobstore_handlers.BlobstoreUploadHandler):
    def post(self):
        upload_files = self.get_uploads('myUploadedFile')
        blob_info = upload_files[0]

        self.response.write('<html><body>')
        self.response.write('Uploaded file: ' + str(blob_info.filename))
        self.response.write('</body></html>')

class ServeFile(blobstore_handlers.BlobstoreDownloadHandler):
    def get(self, resource):
        resource = str(urllib.unquote(resource))
        blob_info = blobstore.BlobInfo.get(resource)
        self.send_blob(blob_info)
        
app = webapp2.WSGIApplication([
    ('/', MainPage), 
    ('/upload', Upload), 
    ('/serve/([^/]+)?', ServeFile),
], debug=True)