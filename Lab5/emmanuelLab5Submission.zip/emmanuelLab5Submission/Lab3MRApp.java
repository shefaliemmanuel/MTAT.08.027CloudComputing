/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ee.ut.cs.ddpc;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;
import org.hsqldb.lib.Collection;

public class Lab3MRApp {

    public static class TokenizerMapper extends Mapper<Object, Text, Text, Text> {

        private Text outkey = new Text();
        private Text outvalue = new Text();

        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {

            String line = value.toString();
            String[] columns = line.split(", ");
            String job = context.getConfiguration().get("occupation", "Tech-Support");

            int[] indexesforNum = {0, 2, 4, 10, 11, 12}; //interested in specific columns

            if (columns[6].equals("Farming-fishing")) {
                for (int i = 0; i < indexesforNum.length; i++) {
                    if (i == 0) {
                        outkey.set(columns[13] + ",Age");
                        outvalue.set(columns[indexesforNum[i]]);
                        context.write(outkey, outvalue);
                    } else if (i == 2) {
                        outkey.set(columns[13] + ",fnlwgt");
                        outvalue.set(columns[indexesforNum[i]]);
                        context.write(outkey, outvalue);
                    } else if (i == 3) {
                        outkey.set(columns[13] + ",ed num");
                        outvalue.set(columns[indexesforNum[i]]);
                        context.write(outkey, outvalue);
                    } else if (i == 4) {
                        outkey.set(columns[13] + ",capital gain");
                        outvalue.set(columns[indexesforNum[i]]);
                        context.write(outkey, outvalue);
                    } else if (i == 5) {
                        outkey.set(columns[13] + ",capital loss");
                        outvalue.set(columns[indexesforNum[i]]);
                        context.write(outkey, outvalue);
                    } else {
                        outkey.set(columns[13] + ",hours/week");
                        outvalue.set(columns[indexesforNum[i]]);
                        context.write(outkey, outvalue);
                    }
                }
            }
        }
    }

    public static class IntSumReducer extends Reducer<Text, Text, Text, Text> {

        private Text result = new Text();

        public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {

            double sum = 0;

            //create an array list
            ArrayList<Double> allValues = new ArrayList<>();

            double peoplesSal;

            for (Text val : values) {
                peoplesSal = Double.parseDouble(val.toString());
                allValues.add(peoplesSal);
                sum += peoplesSal;
            }

            double minSal = Collections.min(allValues);
            String MIN = Double.toString(minSal);
            double avgSal = sum / allValues.size();
            String AVG = Double.toString(avgSal);
            double maxSal = Collections.max(allValues);
            String MAX = Double.toString(maxSal);

            key.set(key.toString() + ",MIN");
            result.set(MIN);
            context.write(key, result);

            key.set(key.toString() + ",AVG");
            result.set(AVG);
            context.write(key, result);

            key.set(key.toString() + ",MAX");
            result.set(MAX);
            context.write(key, result);
        }
    }

    public static void main(String[] args) throws Exception {

        org.apache.log4j.BasicConfigurator.configure();
        org.apache.log4j.Logger.getRootLogger().setLevel(org.apache.log4j.Level.INFO);

        Configuration conf = new Configuration();
        String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();

        if (otherArgs.length < 2) {
            System.err.println("Usage: wordcount <in> [<in>...] <out>");
            System.exit(2);
        }

        conf.set("occupation", otherArgs[2]);
        Job job = Job.getInstance(conf, "word count");
        job.setJarByClass(Lab3MRApp.class);
        job.setMapperClass(TokenizerMapper.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Text.class);
        //job.setCombinerClass(IntSumReducer.class);
        job.setReducerClass(IntSumReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
        FileInputFormat.addInputPath(job, new Path(otherArgs[0]));
        FileOutputFormat.setOutputPath(job, new Path(otherArgs[1]));

        //for (int i = 0; i < otherArgs.length - 1; ++i) {
        //  FileInputFormat.addInputPath(job, new Path(otherArgs[i]));
        //}
        //FileOutputFormat.setOutputPath(job,new Path(otherArgs[otherArgs.length - 1]));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}